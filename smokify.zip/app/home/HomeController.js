smokifyApp.controller('HomeController', ['$scope', function($scope) {
    
}]);